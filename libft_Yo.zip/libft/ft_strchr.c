/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yoherfan <yoherfan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/19 18:50:29 by yoherfan          #+#    #+#             */
/*   Updated: 2024/11/29 17:59:05 by yoherfan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>

char	*ft_strchr(const char *s, int c)
{
	int	i;
	int	toggle;

	i = 0;
	toggle = 0;
	while (s[i] != c && s[i] != '\0')
	{
		if (s[i] == c)
			toggle = 1;
		i++;
	}
	if (toggle == 0)
		return (NULL);
	return ((char *)&s[i]);
}
/*
int main()
{
	const char *str = "oooooa";
	const char *substring1 = ft_strchr(str, 's');
	const char *substring2 = strchr(str, 's');
	printf("%s\n", substring1);
	printf("%s", substring2);
}*/