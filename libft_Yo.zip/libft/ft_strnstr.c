/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yoherfan <yoherfan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/22 17:01:37 by yoherfan          #+#    #+#             */
/*   Updated: 2024/12/02 15:58:06 by yoherfan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <bsd/string.h>

char	*ft_strnstr(const char *big, const char *little, size_t len)
{
	size_t	i;
	size_t	j;

	i = -1;
	while (big[++i] != '\0' && i < len)
	{
		j = 0;
		while (big[j + i] == little[j])
			j++;
		if (little[j] == '\0' && i + j <= len)
			return ((char *)&big[i]);
	}
	return (NULL);
}
/*
int main()
{
	const char str1[100] = "casale";
    const char str2[100] = "asa";
	char *res = ft_strnstr(str1, str2, 1);
	char *res1 = strnstr(str1, str2, 1);
	printf("%s\n", res);
}*/