/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yoherfan <yoherfan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/19 19:10:15 by yoherfan          #+#    #+#             */
/*   Updated: 2024/12/02 16:49:50 by yoherfan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>

char	*ft_strrchr(const char *s, int c)
{
	int	i;
	int	pointer;

	i = 0;
	pointer = 0;
	while (s[i] != '\0')
	{
		if (s[i] == c)
			pointer = i;
		i++;
	}
	if (s[i] == c)
		return ((char *)&s[pointer]);
	if (s[i] == '\0')
		return (NULL);
	else
		return ((char *)&s[pointer]);
}
/*
int main()
{
	const char *str = "bonjour";
	const char *substring1 = ft_strrchr(str, '\0');
	const char *substring1 = strrchr(str, '\0');
	printf("%s", substring1);
}*/
