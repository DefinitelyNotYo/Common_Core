/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yoherfan <yoherfan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/22 14:28:20 by yoherfan          #+#    #+#             */
/*   Updated: 2024/12/02 16:06:20 by yoherfan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <bsd/string.h>

size_t	ft_strlen(const char *s)
{
	size_t	i;

	i = 0;
	while (s[i] != '\0')
		i++;
	return (i);
}

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	size_t	i;

	i = -1;
	if (size == 0)
	{
		while (src[++i] != '\0')
			;
		return (i);
	}
	while (++i < size && src[i] != '\0')
		dst[i] = src[i];
	dst[i] = '\0';
	return (ft_strlen(src));
}
/*
int main()
{
	char	string_dst[15] = "ciao";
	size_t	res;
	
	printf("%s\n", string_dst);
	res = ft_strlcpy(string_dst, "lorem ipsum dolor sit amet", 15);
	res = strlcpy(string_dst, "lorem ipsum dolor sit amet", 15);
	printf("%zu\n", res);
	printf("%s", string_dst);
}*/