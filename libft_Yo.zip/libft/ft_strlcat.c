/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yoherfan <yoherfan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/22 14:54:53 by yoherfan          #+#    #+#             */
/*   Updated: 2024/11/29 17:51:26 by yoherfan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <bsd/string.h>

size_t	ft_strlen(const char *s)
{
	size_t	i;

	i = 0;
	while (s[i] != '\0')
		i++;
	return (i);
}

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	i;
	size_t	j;
	size_t	dst_len;
	size_t	src_len;

	dst_len = ft_strlen(dst);
	src_len = ft_strlen(src);
	if (size <= dst_len)
		return (size + src_len);
	i = dst_len;
	j = 0;
	while (i < (size - 1) && src[j] != '\0')
	{
		dst[i + j] = src[j];
		j++;
	}
	dst[i + j] = '\0';
	return (dst_len + src_len);
}
/*
int main()
{
	char	dest[15];
	dest[10] = 'a';
	size_t	res;

	char	dest1[15];
	dest1[10] = 'a';
	size_t	res1;
	
	printf("%s\n", dest);
	res = ft_strlcat(dest, "lorem ipsum dolor sit amet", 1);

	printf("%zu\n", res);
	printf("%s\n", dest);

	printf("%s\n", dest1);
	res1 = strlcat(dest1, "lorem ipsum dolor sit amet", 1);

	printf("%zu\n", res1);
	printf("%s", dest1);
}*/