/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yoherfan <yoherfan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/12 14:51:30 by yoherfan          #+#    #+#             */
/*   Updated: 2024/12/19 16:08:49 by yoherfan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libftprintf.h"

int	ft_printf_check(int i, va_list ls, const char *r_key)
{
	int	len;

	len = 0;
	if (r_key[i] == '%' && r_key[i + 1] == 'c')
		len += ft_putchar_fd(va_arg(ls, int), 1);
	else if (r_key[i] == '%' && r_key[i + 1] == 's')
		len += ft_putstr_fd(va_arg(ls, char *), 1, 0);
	else if (r_key[i] == '%' && r_key[i + 1] == 'd')
		len += ft_putnbr(va_arg(ls, int), 1, 0, 0);
	else if (r_key[i] == '%' && r_key[i + 1] == 'i')
		len += ft_putnbr(va_arg(ls, int), 1, 0, 0);
	else if (r_key[i] == '%' && r_key[i + 1] == '%')
		len += ft_putchar_fd('%', 1);
	else if (r_key[i] == '%' && r_key[i + 1] == 'u')
		len += ft_putnbr(va_arg(ls, int), 1, 0, 1);
	else if (r_key[i] == '%' && r_key[i + 1] == 'p')
		len += ft_putaddress(va_arg(ls, void *));
	else if (r_key[i] == '%' && r_key[i + 1] == 'X')
		len += ft_putnbr_base(va_arg(ls, unsigned int), "0123456789ABCDEF", 0);
	else if (r_key[i] == '%' && r_key[i + 1] == 'x')
		len += ft_putnbr_base(va_arg(ls, unsigned int), "0123456789abcdef", 0);
	return (len);
}

int	ft_printf(const char *r_key, ...)
{
	va_list	strings;
	int		i;
	int		len;

	if (!r_key)
		return (-1);
	va_start(strings, r_key);
	i = 0;
	len = 0;
	while (r_key[i] != '\0')
	{
		if (r_key[i] == '%')
		{
			len += ft_printf_check(i, strings, r_key);
			i++;
		}
		else
			len += write(1, &r_key[i], 1);
		i++;
	}
	return (len);
}

int	check_base(char *base)
{
	int	i;
	int	j;
	int	len;

	i = 0;
	len = ft_putstr_fd(base, 1, 1);
	if (len < 2)
		return (0);
	while (base[i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-')
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

int	ft_putnbr_exe(long nbr, char *base, int len)
{
	if (nbr == 0 && nbr % ft_putstr_fd(base, 1, 1) == 0)
	{
		return (0);
	}
	else
	{
		len += ft_putnbr_exe(nbr / ft_putstr_fd(base, 1, 1), base, len);
		write(1, &base[nbr % ft_putstr_fd(base, 1, 1)], 1);
		len++;
	}
	return (len);
}

int	ft_putnbr_base(long x, char *base, int len)
{
	if ((int)check_base(base) == 1)
	{
		if (x < 0)
		{
			write(1, "-", 1);
			len++;
			x = x * (-1);
		}
		if (x == 0)
		{
			write(1, &base[0], 1);
			len++;
			return (0);
		}
		else
			len += ft_putnbr_exe(x / ft_putstr_fd(base, 1, 1), base, len);
		write(1, &base[x % ft_putstr_fd(base, 1, 1)], 1);
		len++;
	}
	return (len);
}
